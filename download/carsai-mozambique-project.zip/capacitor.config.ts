import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.carsai.mozambique',
  appName: 'Carsai Mozambique',
  webDir: 'out',
  bundledWebRuntime: false,
  server: {
    androidScheme: 'https',
    // Allow navigation to external URLs for API calls
    allowNavigation: [
      'localhost',
      '127.0.0.1',
    ],
  },
  android: {
    buildOptions: {
      keystorePath: undefined,
      keystoreAlias: undefined,
      keystorePassword: undefined,
      signingType: 'apksigner',
    },
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      launchAutoHide: true,
      backgroundColor: '#ffffff',
      showSpinner: true,
      spinnerColor: '#059669',
      androidScaleType: 'CENTER_CROP',
      androidSpinnerStyle: 'large',
    },
  },
};

export default config;
