import type { NextConfig } from "next";

// Support dual build modes:
// 1. Default (standalone) — web server with API routes
// 2. Export mode — static HTML/CSS/JS for Capacitor/mobile deployment
// Set NEXT_EXPORT_MODE=true for static export (used by Capacitor builds)

const isExportMode = process.env.NEXT_EXPORT_MODE === "true";

const nextConfig: NextConfig = {
  output: isExportMode ? "export" : "standalone",
  images: {
    unoptimized: isExportMode, // Only needed for static export
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
