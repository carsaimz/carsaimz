import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const postId = searchParams.get('postId')

    if (!postId) {
      return NextResponse.json(
        { success: false, message: 'postId query parameter is required' },
        { status: 400 }
      )
    }

    // Verify the post exists
    const post = await db.post.findUnique({
      where: { id: postId },
    })

    if (!post) {
      return NextResponse.json(
        { success: false, message: 'Post not found' },
        { status: 404 }
      )
    }

    const comments = await db.comment.findMany({
      where: {
        postId,
        isApproved: true,
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
          },
        },
        likes: {
          select: {
            id: true,
            userId: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    // Add like count to each comment
    const formattedComments = comments.map((comment) => ({
      ...comment,
      _count: {
        likes: comment.likes.length,
      },
    }))

    return NextResponse.json({
      success: true,
      data: formattedComments,
      count: formattedComments.length,
    })
  } catch (error) {
    console.error('Comments fetch error:', error)
    return NextResponse.json(
      {
        success: false,
        message: 'Failed to fetch comments',
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    )
  }
}

// POST /api/comments — Create a new comment on a blog post
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { postId, content, authorId } = body

    if (!postId || !content || !authorId) {
      return NextResponse.json(
        { success: false, message: 'postId, content, and authorId are required' },
        { status: 400 }
      )
    }

    // Verify the post exists
    const post = await db.post.findUnique({ where: { id: postId } })
    if (!post) {
      return NextResponse.json(
        { success: false, message: 'Post not found' },
        { status: 404 }
      )
    }

    // Verify the author exists
    const author = await db.user.findUnique({ where: { id: authorId } })
    if (!author) {
      return NextResponse.json(
        { success: false, message: 'Author not found' },
        { status: 400 }
      )
    }

    // Create the comment
    const comment = await db.comment.create({
      data: {
        content,
        postId,
        authorId,
        isApproved: true, // Auto-approve for now
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
          },
        },
        likes: {
          select: {
            id: true,
            userId: true,
          },
        },
      },
    })

    return NextResponse.json({
      success: true,
      data: {
        ...comment,
        _count: {
          likes: comment.likes.length,
        },
      },
    }, { status: 201 })
  } catch (error) {
    console.error('Comment creation error:', error)
    return NextResponse.json(
      {
        success: false,
        message: 'Failed to create comment',
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    )
  }
}
