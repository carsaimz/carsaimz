#!/bin/bash
#
# generate-changelog.sh
# Generates a changelog from git commit messages between two tags.
#
# Usage: ./scripts/generate-changelog.sh [PREVIOUS_TAG] [CURRENT_TAG]
#
# If no tags are provided, it will use the last two tags automatically.
# If only one tag is provided, it will use the first commit as the base.
#

set -euo pipefail

PREVIOUS_TAG="${1:-}"
CURRENT_TAG="${2:-}"

# Auto-detect tags if not provided
if [ -z "$CURRENT_TAG" ]; then
  CURRENT_TAG=$(git tag --sort=-version:refname | head -1)
  if [ -z "$CURRENT_TAG" ]; then
    echo "No git tags found. Create a tag first with: git tag v0.1.0"
    exit 1
  fi
fi

if [ -z "$PREVIOUS_TAG" ]; then
  PREVIOUS_TAG=$(git tag --sort=-version:refname | grep -v "^${CURRENT_TAG}$" | head -1)
fi

# Determine the commit range
if [ -n "$PREVIOUS_TAG" ]; then
  COMMIT_RANGE="${PREVIOUS_TAG}..${CURRENT_TAG}"
  RANGE_LABEL="${PREVIOUS_TAG} → ${CURRENT_TAG}"
else
  COMMIT_RANGE="${CURRENT_TAG}"
  RANGE_LABEL="Initial → ${CURRENT_TAG}"
fi

echo "# Changelog"
echo ""
echo "## ${CURRENT_TAG} ($(date +%Y-%m-%d))"
echo ""
echo "### Changes (${RANGE_LABEL})"
echo ""

# Categorize commits
FEATURE_COMMITS=""
BUGFIX_COMMITS=""
OTHER_COMMITS=""

while IFS= read -r commit; do
  if [ -z "$commit" ]; then continue; fi

  # Extract the commit subject (first line)
  subject=$(echo "$commit" | head -1)

  # Categorize based on conventional commit prefixes
  if echo "$subject" | grep -qiE '^(feat|feature|add|\+)'; then
    FEATURE_COMMITS="${FEATURE_COMMITS}- ${subject}\n"
  elif echo "$subject" | grep -qiE '^(fix|bugfix|patch|hotfix|\-)'; then
    BUGFIX_COMMITS="${BUGFIX_COMMITS}- ${subject}\n"
  else
    OTHER_COMMITS="${OTHER_COMMITS}- ${subject}\n"
  fi
done < <(git log --format="%s" "$COMMIT_RANGE" 2>/dev/null || echo "")

# Output categorized sections
if [ -n "$FEATURE_COMMITS" ]; then
  echo "### ✨ Features"
  echo ""
  echo -e "$FEATURE_COMMITS"
fi

if [ -n "$BUGFIX_COMMITS" ]; then
  echo "### 🐛 Bug Fixes"
  echo ""
  echo -e "$BUGFIX_COMMITS"
fi

if [ -n "$OTHER_COMMITS" ]; then
  echo "### 📝 Other Changes"
  echo ""
  echo -e "$OTHER_COMMITS"
fi

# Add contributor info
echo ""
echo "### Contributors"
echo ""
git log --format="- @%an" "$COMMIT_RANGE" 2>/dev/null | sort -u | head -20 || echo "- N/A"
echo ""

# Add stats
echo "### Stats"
echo ""
TOTAL_COMMITS=$(git log --oneline "$COMMIT_RANGE" 2>/dev/null | wc -l || echo "0")
TOTAL_FILES=$(git diff --stat "$COMMIT_RANGE" 2>/dev/null | tail -1 || echo "N/A")
echo "- Total commits: ${TOTAL_COMMITS}"
echo "- Files changed: ${TOTAL_FILES}"
