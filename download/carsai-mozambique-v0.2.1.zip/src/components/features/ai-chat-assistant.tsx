'use client';

import {
  useState,
  useRef,
  useEffect,
  useCallback,
  type PointerEvent as ReactPointerEvent,
} from 'react';
import { motion, AnimatePresence, useMotionValue } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import {
  MessageCircle,
  X,
  Send,
  Bot,
  User,
  Sparkles,
  Minimize2,
  Maximize2,
  Trash2,
  Globe,
  RefreshCw,
  ChevronUp,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useLanguage } from '@/contexts/language-context';

// ──────────────────────────────────────────────
// Types & Constants
// ──────────────────────────────────────────────

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

type WindowState = 'closed' | 'normal' | 'minimized' | 'fullscreen';

const STORAGE_KEY = 'carsai_chat_messages';
const SESSION_KEY = 'carsai_chat_session';
const POSITION_KEY = 'carsai_chat_position';
const MAX_MESSAGES = 50;

// ──────────────────────────────────────────────
// localStorage helpers
// ──────────────────────────────────────────────

function loadMessages(): ChatMessage[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) return JSON.parse(stored).slice(-MAX_MESSAGES);
  } catch { /* ignore */ }
  return [];
}

function saveMessages(messages: ChatMessage[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(messages.slice(-MAX_MESSAGES)));
  } catch { /* ignore */ }
}

function clearMessages() {
  try {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(SESSION_KEY);
  } catch { /* ignore */ }
}

function getOrCreateSessionId(): string {
  try {
    const existing = localStorage.getItem(SESSION_KEY);
    if (existing) return existing;
    const newId = `session-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    localStorage.setItem(SESSION_KEY, newId);
    return newId;
  } catch {
    return `session-${Date.now()}`;
  }
}

function loadPosition(): { x: number; y: number } {
  try {
    const stored = localStorage.getItem(POSITION_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (typeof parsed.x === 'number' && typeof parsed.y === 'number') return parsed;
    }
  } catch { /* ignore */ }
  return { x: 0, y: 0 };
}

function savePosition(x: number, y: number) {
  try {
    localStorage.setItem(POSITION_KEY, JSON.stringify({ x, y }));
  } catch { /* ignore */ }
}

// ──────────────────────────────────────────────
// Hook: useDraggable (only in normal state on desktop)
// ──────────────────────────────────────────────

function useDraggable(isEnabled: boolean) {
  const isDragging = useRef(false);
  const dragStart = useRef({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const currentPosition = useRef({ x: 0, y: 0 });
  const motionX = useMotionValue(0);
  const motionY = useMotionValue(0);

  useEffect(() => {
    if (!isEnabled) {
      const saved = loadPosition();
      currentPosition.current = saved;
      motionX.set(saved.x);
      motionY.set(saved.y);
    } else {
      const saved = loadPosition();
      currentPosition.current = saved;
      motionX.set(saved.x);
      motionY.set(saved.y);
    }
  }, [isEnabled, motionX, motionY]);

  const onPointerDown = useCallback(
    (e: ReactPointerEvent<HTMLDivElement>) => {
      if (!isEnabled) return;
      const target = e.target as HTMLElement;
      if (target.closest('button') || target.closest('[data-no-drag]')) return;
      isDragging.current = true;
      dragStart.current = {
        x: e.clientX - currentPosition.current.x,
        y: e.clientY - currentPosition.current.y,
      };
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
    },
    [isEnabled],
  );

  const onPointerMove = useCallback(
    (e: ReactPointerEvent<HTMLDivElement>) => {
      if (!isDragging.current) return;
      const newX = e.clientX - dragStart.current.x;
      const newY = e.clientY - dragStart.current.y;
      const container = containerRef.current;
      if (container) {
        const rect = container.getBoundingClientRect();
        const vw = window.innerWidth;
        const vh = window.innerHeight;
        const constrainedX = Math.max(0, Math.min(vw - rect.width, newX));
        const constrainedY = Math.max(0, Math.min(vh - rect.height, newY));
        currentPosition.current = { x: constrainedX, y: constrainedY };
        motionX.set(constrainedX);
        motionY.set(constrainedY);
      }
    },
    [motionX, motionY],
  );

  const onPointerUp = useCallback(() => {
    if (isDragging.current) {
      isDragging.current = false;
      savePosition(currentPosition.current.x, currentPosition.current.y);
    }
  }, []);

  return {
    containerRef,
    motionX,
    motionY,
    onPointerDown,
    onPointerMove,
    onPointerUp,
  };
}

// ──────────────────────────────────────────────
// Animation Variants
// ──────────────────────────────────────────────

const bubbleVariants = {
  hidden: { opacity: 0, scale: 0 },
  visible: {
    opacity: 1, scale: 1,
    transition: { type: 'spring', stiffness: 400, damping: 20 },
  },
  exit: { opacity: 0, scale: 0, transition: { duration: 0.2 } },
};

const windowVariants = {
  hidden: { opacity: 0, scale: 0.6, y: 40, transformOrigin: 'bottom right' },
  visible: {
    opacity: 1, scale: 1, y: 0, transformOrigin: 'bottom right',
    transition: { type: 'spring', stiffness: 300, damping: 24 },
  },
  exit: { opacity: 0, scale: 0.6, y: 40, transformOrigin: 'bottom right', transition: { duration: 0.2 } },
};

const minimizedVariants = {
  hidden: { opacity: 0, y: 60, scale: 0.8, transformOrigin: 'bottom center' },
  visible: {
    opacity: 1, y: 0, scale: 1, transformOrigin: 'bottom center',
    transition: { type: 'spring', stiffness: 350, damping: 25 },
  },
  exit: { opacity: 0, y: 60, scale: 0.8, transformOrigin: 'bottom center', transition: { duration: 0.15 } },
};

const fullscreenVariants = {
  hidden: { opacity: 0, scale: 0.85 },
  visible: { opacity: 1, scale: 1, transition: { type: 'spring', stiffness: 250, damping: 22 } },
  exit: { opacity: 0, scale: 0.85, transition: { duration: 0.2 } },
};

const messageVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.3 } },
};

// ──────────────────────────────────────────────
// Markdown Components (custom rendering for chat)
// ──────────────────────────────────────────────

const markdownComponents = {
  a: ({ href, children, ...props }: React.AnchorHTMLAttributes<HTMLAnchorElement>) => (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="text-emerald-600 dark:text-emerald-400 underline decoration-emerald-400/60 hover:decoration-emerald-600 hover:text-emerald-700 dark:hover:text-emerald-300 transition-colors break-all"
      {...props}
    >
      {children}
    </a>
  ),
  p: ({ children }: React.HTMLAttributes<HTMLParagraphElement>) => (
    <p className="mb-2 last:mb-0 leading-relaxed">{children}</p>
  ),
  ul: ({ children }: React.HTMLAttributes<HTMLUListElement>) => (
    <ul className="list-disc pl-4 mb-2 space-y-1">{children}</ul>
  ),
  ol: ({ children }: React.HTMLAttributes<HTMLOListElement>) => (
    <ol className="list-decimal pl-4 mb-2 space-y-1">{children}</ol>
  ),
  li: ({ children }: React.HTMLAttributes<HTMLLIElement>) => (
    <li className="leading-relaxed">{children}</li>
  ),
  strong: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <strong className="font-semibold text-foreground">{children}</strong>
  ),
  em: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <em className="italic">{children}</em>
  ),
  code: ({ className, children, ...props }: React.HTMLAttributes<HTMLElement> & { inline?: boolean }) => {
    const isInline = !className;
    return isInline
      ? <code className="bg-muted/60 px-1.5 py-0.5 rounded text-sm font-mono text-emerald-700 dark:text-emerald-400" {...props}>{children}</code>
      : (
        <code className={`${className || ''} block bg-muted/60 rounded-lg p-3 my-2 overflow-x-auto text-sm font-mono`} {...props}>
          {children}
        </code>
      );
  },
  pre: ({ children }: React.HTMLAttributes<HTMLPreElement>) => (
    <pre className="bg-muted/40 dark:bg-muted/60 rounded-lg p-3 my-2 overflow-x-auto border border-border/50">{children}</pre>
  ),
  h1: ({ children }: React.HTMLAttributes<HTMLHeadingElement>) => (
    <h1 className="text-lg font-bold mb-2 mt-3">{children}</h1>
  ),
  h2: ({ children }: React.HTMLAttributes<HTMLHeadingElement>) => (
    <h2 className="text-base font-semibold mb-2 mt-2">{children}</h2>
  ),
  h3: ({ children }: React.HTMLAttributes<HTMLHeadingElement>) => (
    <h3 className="text-sm font-semibold mb-1.5 mt-2">{children}</h3>
  ),
  blockquote: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <blockquote className="border-l-3 border-emerald-500 pl-3 my-2 text-muted-foreground italic">{children}</blockquote>
  ),
};

// ──────────────────────────────────────────────
// Main Component
// ──────────────────────────────────────────────

export function AiChatAssistant() {
  const { t } = useLanguage();
  const [windowState, setWindowState] = useState<WindowState>('closed');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sessionId, setSessionId] = useState('');
  const [hasError, setHasError] = useState(false);
  const [hasUnread, setHasUnread] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const prevMessageCountRef = useRef(0);
  const prevWindowStateRef = useRef<WindowState>('closed');
  const isDesktop = useRef(true);

  // ── Check desktop ──
  useEffect(() => {
    const check = () => { isDesktop.current = window.innerWidth >= 1024; };
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  // ── Draggable (normal state, desktop only) ──
  const draggable = useDraggable(windowState === 'normal' && isDesktop.current);

  // ── Quick questions (i18n) ──
  const quickQuestions = [
    t('chat.quickQuestion1'),
    t('chat.quickQuestion2'),
    t('chat.quickQuestion3'),
    t('chat.quickQuestion4'),
  ];

  // ── Initialize session ──
  useEffect(() => {
    setSessionId(getOrCreateSessionId());
    const stored = loadMessages();
    if (stored.length > 0) setMessages(stored);
  }, []);

  // ── Persist messages ──
  useEffect(() => {
    if (messages.length > 0) saveMessages(messages);
  }, [messages]);

  // ── Unread tracking ──
  useEffect(() => {
    const prevState = prevWindowStateRef.current;
    const prevCount = prevMessageCountRef.current;
    if (
      (prevState === 'closed' || prevState === 'minimized') &&
      messages.length > prevCount &&
      messages[messages.length - 1]?.role === 'assistant'
    ) {
      setHasUnread(true);
    }
    prevMessageCountRef.current = messages.length;
  }, [messages]);

  useEffect(() => {
    if (windowState === 'normal' || windowState === 'fullscreen') setHasUnread(false);
    prevWindowStateRef.current = windowState;
  }, [windowState]);

  // ── Auto-scroll to bottom on new messages ──
  useEffect(() => {
    if (bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
  }, [messages, isLoading]);

  // ── Focus input on open ──
  useEffect(() => {
    if ((windowState === 'normal' || windowState === 'fullscreen') && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [windowState]);

  // ── Initialize greeting ──
  useEffect(() => {
    if ((windowState === 'normal' || windowState === 'fullscreen') && messages.length === 0) {
      setMessages([{
        id: 'greeting',
        role: 'assistant',
        content: t('chat.greeting'),
        timestamp: Date.now(),
      }]);
    }
  }, [windowState, messages.length, t]);

  // ── ESC key ──
  useEffect(() => {
    const handle = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (windowState === 'fullscreen') setWindowState('normal');
        else if (windowState === 'normal' || windowState === 'minimized') setWindowState('closed');
      }
    };
    window.addEventListener('keydown', handle);
    return () => window.removeEventListener('keydown', handle);
  }, [windowState]);

  // ── Send message ──
  const sendMessage = async (content: string) => {
    if (!content.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: content.trim(),
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setHasError(false);

    try {
      const contextMessages = messages.slice(-10).map(m => ({ role: m.role, content: m.content }));
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: content.trim(), context: contextMessages, sessionId }),
      });
      const data = await response.json();

      if (data.success && data.response) {
        setMessages(prev => [...prev, {
          id: `assistant-${Date.now()}`,
          role: 'assistant',
          content: data.response,
          timestamp: Date.now(),
        }]);
        if (data.sessionId) {
          setSessionId(data.sessionId);
          try { localStorage.setItem(SESSION_KEY, data.sessionId); } catch { /* */ }
        }
      } else {
        setHasError(true);
        setMessages(prev => [...prev, {
          id: `error-${Date.now()}`,
          role: 'assistant',
          content: t('chat.error'),
          timestamp: Date.now(),
        }]);
      }
    } catch {
      setHasError(true);
      setMessages(prev => [...prev, {
        id: `error-${Date.now()}`,
        role: 'assistant',
        content: t('chat.error'),
        timestamp: Date.now(),
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); sendMessage(input); };
  const handleQuickQuestion = (q: string) => sendMessage(q);
  const handleClearHistory = () => {
    setMessages([]);
    clearMessages();
    setSessionId(getOrCreateSessionId());
    setMessages([{ id: 'greeting-new', role: 'assistant', content: t('chat.greeting'), timestamp: Date.now() }]);
  };
  const handleRetry = () => {
    const lastUserMsg = [...messages].reverse().find(m => m.role === 'user');
    if (lastUserMsg) {
      setMessages(prev => prev.filter(m => m.timestamp <= lastUserMsg.timestamp));
      sendMessage(lastUserMsg.content);
    }
  };

  const formatTime = (ts: number) =>
    new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // ── Window controls ──
  const openNormal = () => setWindowState('normal');
  const minimize = () => setWindowState('minimized');
  const maximize = () => setWindowState('fullscreen');
  const closeChat = () => setWindowState('closed');

  // ──────────────────────────────────────────────
  // Sub-components
  // ──────────────────────────────────────────────

  // ── Header with window controls ──
  const ChatHeader = ({ compact = false }: { compact?: boolean }) => (
    <div
      className={`bg-gradient-to-r from-emerald-600 via-emerald-500 to-green-500 text-white select-none cursor-grab active:cursor-grabbing ${
        compact ? 'py-2 px-3' : 'py-2.5 px-4'
      }`}
    >
      {/* Main row: logo + title + controls */}
      <div className="flex items-center justify-between gap-2">
        {/* Logo & title — allow text to flow naturally */}
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <div className={`shrink-0 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center ${
            compact ? 'size-5' : 'size-7'
          }`}>
            <Bot className={`${compact ? 'size-2.5' : 'size-3.5'} text-white`} />
          </div>
          <div className="min-w-0 flex-1">
            <span className={`font-semibold block ${compact ? 'text-[10px] leading-tight' : 'text-sm leading-snug'}`}>
              {t('chat.title')}
            </span>
            {!compact && (
              <span className="text-[11px] text-emerald-100/80 block leading-tight">
                {t('chat.subtitle')}
              </span>
            )}
          </div>
        </div>

        {/* Window controls — always visible */}
        <div className="flex items-center gap-0.5 shrink-0" data-no-drag>
          {/* Clear history */}
          {!compact && messages.length > 2 && (
            <Button
              variant="ghost" size="icon"
              className="size-6 text-emerald-100 hover:bg-emerald-800/50 hover:text-white"
              onClick={handleClearHistory}
              aria-label="Clear history"
            >
              <Trash2 className="size-3" />
            </Button>
          )}
          {/* Minimize — normal state */}
          {windowState === 'normal' && (
            <Button
              variant="ghost" size="icon"
              className="size-6 text-emerald-100 hover:bg-emerald-800/50 hover:text-white"
              onClick={minimize}
              aria-label="Minimize"
            >
              <Minimize2 className="size-3" />
            </Button>
          )}
          {/* Maximize — normal state */}
          {windowState === 'normal' && (
            <Button
              variant="ghost" size="icon"
              className="size-6 text-emerald-100 hover:bg-emerald-800/50 hover:text-white"
              onClick={maximize}
              aria-label="Maximize"
            >
              <Maximize2 className="size-3" />
            </Button>
          )}
          {/* Restore from fullscreen */}
          {windowState === 'fullscreen' && (
            <Button
              variant="ghost" size="icon"
              className="size-6 text-emerald-100 hover:bg-emerald-800/50 hover:text-white"
              onClick={() => setWindowState('normal')}
              aria-label="Restore"
            >
              <Minimize2 className="size-3" />
            </Button>
          )}
          {/* Restore from minimized */}
          {windowState === 'minimized' && (
            <Button
              variant="ghost" size="icon"
              className={`${compact ? 'size-5' : 'size-6'} text-emerald-100 hover:bg-emerald-800/50 hover:text-white`}
              onClick={() => setWindowState('normal')}
              aria-label="Restore"
            >
              <ChevronUp className={`${compact ? 'size-2.5' : 'size-3'}`} />
            </Button>
          )}
          {/* Close */}
          <Button
            variant="ghost" size="icon"
            className={`${compact ? 'size-5' : 'size-6'} text-emerald-100 hover:bg-red-500/40 hover:text-white`}
            onClick={closeChat}
            aria-label={t('chat.close')}
          >
            <X className={`${compact ? 'size-2.5' : 'size-3'}`} />
          </Button>
        </div>
      </div>

      {/* Status badges — only in non-compact */}
      {!compact && (
        <div className="flex items-center gap-1.5 mt-1.5">
          <Badge className="bg-white/10 backdrop-blur-sm text-emerald-100 border-emerald-400/20 text-[10px] px-1.5 py-0 h-4">
            <Globe className="size-2.5 mr-0.5" />{t('chat.dbConnected')}
          </Badge>
          {messages.length > 1 && (
            <Badge className="bg-white/10 backdrop-blur-sm text-emerald-100 border-emerald-400/20 text-[10px] px-1.5 py-0 h-4">
              <Sparkles className="size-2.5 mr-0.5" />{messages.length - 1} {t('chat.messagesInMemory')}
            </Badge>
          )}
        </div>
      )}
    </div>
  );

  // ── Single message bubble ──
  const MessageBubble = ({ msg }: { msg: ChatMessage }) => (
    <motion.div
      key={msg.id}
      variants={messageVariants}
      initial="hidden"
      animate="visible"
      className={`flex gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
    >
      {msg.role === 'assistant' && (
        <div className="shrink-0 size-7 rounded-full bg-gradient-to-br from-emerald-100 to-emerald-200 dark:from-emerald-900 dark:to-emerald-800 flex items-center justify-center shadow-sm mt-1">
          <Bot className="size-3.5 text-emerald-700 dark:text-emerald-400" />
        </div>
      )}
      <div className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-sm shadow-sm ${
        msg.role === 'user'
          ? 'bg-gradient-to-r from-emerald-600 to-emerald-700 text-white shadow-md shadow-emerald-600/20 rounded-br-sm'
          : 'bg-white dark:bg-muted/80 text-foreground border border-emerald-200/60 dark:border-emerald-800/40 rounded-bl-sm'
      }`}>
        {msg.role === 'assistant' ? (
          <div className="whitespace-pre-wrap break-words leading-relaxed prose-sm max-w-none [&_a]:text-emerald-600 [&_a]:dark:text-emerald-400 [&_a]:underline [&_a]:hover:text-emerald-700 [&_a]:dark:hover:text-emerald-300">
            <ReactMarkdown components={markdownComponents}>{msg.content}</ReactMarkdown>
          </div>
        ) : (
          <p className="whitespace-pre-wrap break-words leading-relaxed">{msg.content}</p>
        )}
        <p className={`text-[10px] mt-1 ${
          msg.role === 'user' ? 'text-emerald-200/60' : 'text-muted-foreground/50'
        }`}>
          {formatTime(msg.timestamp)}
        </p>
      </div>
      {msg.role === 'user' && (
        <div className="shrink-0 size-7 rounded-full bg-gradient-to-br from-emerald-600 to-emerald-700 flex items-center justify-center shadow-md shadow-emerald-600/20 mt-1">
          <User className="size-3.5 text-white" />
        </div>
      )}
    </motion.div>
  );

  // ── Typing indicator ──
  const TypingIndicator = () => (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }}
      className="flex gap-2 justify-start"
    >
      <div className="shrink-0 size-7 rounded-full bg-gradient-to-br from-emerald-100 to-emerald-200 dark:from-emerald-900 dark:to-emerald-800 flex items-center justify-center">
        <Bot className="size-3.5 text-emerald-700 dark:text-emerald-400" />
      </div>
      <div className="bg-white dark:bg-muted/80 rounded-2xl rounded-bl-sm px-4 py-3 border border-emerald-200/60 dark:border-emerald-800/40 shadow-sm">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5">
            <span className="animate-bounce size-2 rounded-full bg-emerald-600 [animation-delay:0ms]" />
            <span className="animate-bounce size-2 rounded-full bg-emerald-500 [animation-delay:150ms]" />
            <span className="animate-bounce size-2 rounded-full bg-emerald-400 [animation-delay:300ms]" />
          </div>
          <span className="text-xs text-muted-foreground">{t('chat.thinking')}</span>
        </div>
      </div>
    </motion.div>
  );

  // ── Error with retry ──
  const ErrorRetry = () => (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }}
      className="flex gap-2 justify-start"
    >
      <div className="bg-red-50 dark:bg-red-950/30 rounded-2xl px-3 py-2 border border-red-200/60 dark:border-red-800/40">
        <p className="text-sm text-red-700 dark:text-red-400 mb-2">{t('chat.error')}</p>
        <Button
          size="sm" variant="outline"
          className="text-xs border-red-200 text-red-700 hover:bg-red-100"
          onClick={handleRetry}
        >
          <RefreshCw className="size-3 mr-1" />Retry
        </Button>
      </div>
    </motion.div>
  );

  // ── Messages area ──
  const ChatMessages = () => (
    <CardContent className="flex-1 p-0 overflow-hidden bg-gradient-to-b from-background to-muted/10">
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto overflow-x-hidden px-4 py-3 max-h-[60vh] lg:max-h-none"
        style={{ scrollbarWidth: 'thin', scrollbarColor: '#10b981 transparent' }}
      >
        <div className="flex flex-col gap-3">
          {messages.map(msg => <MessageBubble key={msg.id} msg={msg} />)}
          {isLoading && <TypingIndicator />}
          {hasError && !isLoading && <ErrorRetry />}
          {/* Anchor for auto-scroll */}
          <div ref={bottomRef} className="h-1" />
        </div>
      </div>

      {/* Quick questions */}
      {messages.length <= 2 && !isLoading && (
        <div className="px-4 pb-2">
          <Separator className="mb-2 bg-emerald-200/40 dark:bg-emerald-800/40" />
          <p className="text-xs text-muted-foreground mb-2 font-medium">
            {t('chat.frequentQuestions')}
          </p>
          <div className="flex flex-wrap gap-1.5">
            {quickQuestions.map((q, i) => (
              <Button
                key={i} variant="outline" size="sm"
                className="text-xs h-auto py-1.5 px-3 border-emerald-300/60 dark:border-emerald-700/60 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-900/50 rounded-xl shadow-sm transition-all hover:shadow-md"
                onClick={() => handleQuickQuestion(q)}
              >
                {q}
              </Button>
            ))}
          </div>
        </div>
      )}
    </CardContent>
  );

  // ── Input area ──
  const ChatInput = () => (
    <div className="border-t border-emerald-200/40 dark:border-emerald-800/40 p-3 bg-gradient-to-r from-emerald-50/60 to-green-50/60 dark:from-emerald-950/40 dark:to-green-950/40">
      <form onSubmit={handleSubmit} className="flex gap-2">
        <Input
          ref={inputRef}
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder={t('chat.placeholder')}
          disabled={isLoading}
          className="text-sm border-emerald-300/60 dark:border-emerald-700/60 focus-visible:ring-emerald-500 bg-white dark:bg-background rounded-xl"
        />
        <Button
          type="submit" size="icon"
          disabled={!input.trim() || isLoading}
          className="bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white shrink-0 rounded-xl shadow-md shadow-emerald-600/20 transition-all"
        >
          <Send className="size-4" />
        </Button>
      </form>
      <p className="text-[10px] text-muted-foreground/50 mt-1 text-center">
        {t('chat.poweredBy')}
      </p>
    </div>
  );

  // ──────────────────────────────────────────────
  // Render — 4 window states
  // ──────────────────────────────────────────────

  return (
    <>
      {/* ── Closed: Floating emerald bubble with pulse ── */}
      <AnimatePresence>
        {windowState === 'closed' && (
          <motion.button
            variants={bubbleVariants}
            initial="hidden"
            animate={hasUnread ? 'visible' : {
              ...bubbleVariants.visible,
              scale: [1, 1.05, 1],
              boxShadow: [
                '0 0 0 0 rgba(16, 185, 129, 0.4)',
                '0 0 0 12px rgba(16, 185, 129, 0)',
                '0 0 0 0 rgba(16, 185, 129, 0)',
              ],
            }}
            transition={!hasUnread ? {
              scale: { repeat: Infinity, duration: 2.5, ease: 'easeInOut' },
              boxShadow: { repeat: Infinity, duration: 2.5, ease: 'easeInOut' },
            } : undefined}
            exit="hidden"
            onClick={openNormal}
            className="fixed bottom-6 right-6 z-50 flex items-center justify-center size-14 rounded-full bg-gradient-to-br from-emerald-500 to-emerald-700 hover:from-emerald-600 hover:to-emerald-800 text-white shadow-lg shadow-emerald-600/30 hover:shadow-xl hover:shadow-emerald-600/40 transition-colors group"
            aria-label={t('chat.open')}
          >
            <MessageCircle className="size-6 group-hover:scale-110 transition-transform" />
            <Badge className="absolute -top-1 -right-1 size-5 p-0 bg-yellow-400 text-emerald-900 text-[10px] flex items-center justify-center border-0 rounded-full shadow-sm">
              <Sparkles className="size-3" />
            </Badge>
            {/* Unread dot */}
            {hasUnread && (
              <motion.div
                initial={{ scale: 0 }} animate={{ scale: 1 }}
                className="absolute -top-1.5 -left-1.5 size-4 rounded-full bg-red-500 border-2 border-white shadow-md animate-pulse"
              >
                <span className="sr-only">New messages</span>
              </motion.div>
            )}
          </motion.button>
        )}
      </AnimatePresence>

      {/* ── Minimized: Small bar with unread count ── */}
      <AnimatePresence>
        {windowState === 'minimized' && (
          <motion.div
            variants={minimizedVariants}
            initial="hidden" animate="visible" exit="exit"
            className="fixed bottom-4 left-1/2 -translate-x-1/2 sm:left-auto sm:translate-x-0 sm:right-6 z-50 w-[90vw] sm:w-auto"
          >
            <Card className="border-emerald-200/60 dark:border-emerald-800/60 shadow-xl shadow-emerald-900/20 overflow-hidden rounded-xl">
              <ChatHeader compact />
              {/* Unread count on minimized bar */}
              {hasUnread && messages.length > 0 && (
                <div
                  className="flex items-center justify-center gap-2 py-1.5 px-3 bg-emerald-50 dark:bg-emerald-950/30 cursor-pointer hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-colors border-t border-emerald-200/40 dark:border-emerald-800/40"
                  onClick={() => setWindowState('normal')}
                  data-no-drag
                >
                  <Badge className="bg-emerald-600 text-white text-xs px-2 py-0.5 animate-pulse">
                    {messages.filter(m => m.role === 'assistant').length} {t('chat.messagesInMemory')}
                  </Badge>
                  <ChevronUp className="size-3 text-emerald-600 dark:text-emerald-400" />
                </div>
              )}
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Normal: Draggable floating window ── */}
      <AnimatePresence>
        {windowState === 'normal' && (
          <motion.div
            ref={draggable.containerRef}
            variants={windowVariants}
            initial="hidden" animate="visible" exit="exit"
            style={{
              x: isDesktop.current ? draggable.motionX : 0,
              y: isDesktop.current ? draggable.motionY : 0,
            }}
            onPointerDown={draggable.onPointerDown}
            onPointerMove={draggable.onPointerMove}
            onPointerUp={draggable.onPointerUp}
            className={`fixed z-50 ${
              isDesktop.current ? '' : 'bottom-6 right-6'
            } w-[90vw] sm:w-[60vw] md:w-[40vw] lg:w-[30vw] h-[70vh] lg:h-[60vh]`}
          >
            <Card className="border-emerald-200/60 dark:border-emerald-800/60 shadow-2xl shadow-emerald-900/20 h-full flex flex-col overflow-hidden rounded-2xl">
              <ChatHeader />
              <ChatMessages />
              <ChatInput />
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Fullscreen ── */}
      <AnimatePresence>
        {windowState === 'fullscreen' && (
          <motion.div
            variants={fullscreenVariants}
            initial="hidden" animate="visible" exit="exit"
            className="fixed inset-0 z-50 p-2 sm:p-3 w-[95vw] h-[90vh] mx-auto"
          >
            <Card className="border-emerald-200/60 dark:border-emerald-800/60 shadow-2xl shadow-emerald-900/20 h-full flex flex-col overflow-hidden rounded-2xl">
              <ChatHeader />
              <ChatMessages />
              <ChatInput />
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
