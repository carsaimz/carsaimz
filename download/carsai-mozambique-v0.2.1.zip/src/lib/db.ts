/**
 * Carsai Mozambique - Database Client
 *
 * This module provides the Prisma client connected to Supabase PostgreSQL.
 * The schema is unified with the Supabase migration SQL file.
 *
 * DATABASE_URL format for Supabase:
 *   postgresql://postgres:[PASSWORD]@db.kngwnzvotefivjmaleup.supabase.co:5432/postgres
 *
 * DIRECT_URL format (for migrations):
 *   Same as DATABASE_URL but with connection pooling disabled
 */

import { PrismaClient } from '@prisma/client'

// ──────────────────────────────────────────────
// Prisma client (PostgreSQL / Supabase)
// ──────────────────────────────────────────────

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db = globalForPrisma.prisma ?? new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
})

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
