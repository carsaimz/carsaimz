import pg from 'pg';
const { Pool } = pg;

const POOLER_URL = 'postgresql://postgres.kngwnzvotefivjmaleup:Carnanda23%3F@aws-0-ap-northeast-1.pooler.supabase.com:6543/postgres';

const SQL_STATEMENTS = [
  `CREATE TABLE IF NOT EXISTS post_likes (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
    post_id TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(post_id, user_id)
  )`,
  `CREATE TABLE IF NOT EXISTS comment_likes (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
    comment_id TEXT NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(comment_id, user_id)
  )`,
  `CREATE TABLE IF NOT EXISTS forum_post_likes (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
    post_id TEXT NOT NULL REFERENCES forum_posts(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(post_id, user_id)
  )`,
  `CREATE INDEX IF NOT EXISTS idx_post_likes_post_id ON post_likes(post_id)`,
  `CREATE INDEX IF NOT EXISTS idx_post_likes_user_id ON post_likes(user_id)`,
  `CREATE INDEX IF NOT EXISTS idx_comment_likes_comment_id ON comment_likes(comment_id)`,
  `CREATE INDEX IF NOT EXISTS idx_comment_likes_user_id ON comment_likes(user_id)`,
  `CREATE INDEX IF NOT EXISTS idx_forum_post_likes_post_id ON forum_post_likes(post_id)`,
  `CREATE INDEX IF NOT EXISTS idx_forum_post_likes_user_id ON forum_post_likes(user_id)`,
  `INSERT INTO roles (name, description) VALUES
    ('super_admin', 'Administrador supremo com acesso total'),
    ('admin', 'Administrador com acesso a gestao'),
    ('partner', 'Parceiro/afiliado'),
    ('user', 'Utilizador regular')
  ON CONFLICT (name) DO NOTHING`,
  `INSERT INTO permissions (name, description) VALUES
    ('admin:full', 'Acesso total'), ('admin:read', 'Leitura admin'),
    ('admin:write', 'Escrita admin'), ('partner:manage', 'Gerir parceiros'),
    ('partner:read', 'Leitura parceiro'), ('user:read', 'Leitura utilizador'),
    ('user:write', 'Escrita utilizador'), ('forum:post', 'Criar no forum'),
    ('forum:moderate', 'Moderar forum'), ('blog:write', 'Escrita blog'),
    ('blog:comment', 'Comentar blog')
  ON CONFLICT (name) DO NOTHING`,
  `INSERT INTO role_permissions (role_id, permission_id)
    SELECT r.id, p.id FROM roles r, permissions p WHERE r.name = 'super_admin'
  ON CONFLICT (role_id, permission_id) DO NOTHING`,
];

async function main() {
  console.log('Conectando ao Supabase (ap-northeast-1)...');
  
  const pool = new Pool({
    connectionString: POOLER_URL,
    max: 1,
    connectionTimeoutMillis: 15000,
    idleTimeoutMillis: 10000,
  });

  try {
    const test = await pool.query('SELECT current_database(), current_user');
    console.log('Conectado:', test.rows[0]);
    
    for (let i = 0; i < SQL_STATEMENTS.length; i++) {
      const sql = SQL_STATEMENTS[i];
      const label = sql.substring(0, 60).replace(/\n/g, ' ').trim();
      try {
        await pool.query(sql);
        console.log(`OK [${i+1}/${SQL_STATEMENTS.length}]: ${label}...`);
      } catch (err: any) {
        if (err.message?.includes('already exists')) {
          console.log(`SKIP [${i+1}/${SQL_STATEMENTS.length}]: ${label}... (ja existe)`);
        } else {
          console.log(`ERR [${i+1}/${SQL_STATEMENTS.length}]: ${label}... - ${err.message}`);
        }
      }
    }
    
    // Verify
    const verify = await pool.query(
      "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name IN ('post_likes', 'comment_likes', 'forum_post_likes') ORDER BY table_name"
    );
    console.log('');
    console.log('Tabelas de likes verificadas:', verify.rows.map(r => r.table_name));
    
    // Count all tables
    const allTables = await pool.query(
      "SELECT count(*) as total FROM information_schema.tables WHERE table_schema = 'public'"
    );
    console.log('Total de tabelas no schema public:', allTables.rows[0].total);
    
  } catch (error: any) {
    console.error('Erro:', error.message);
  } finally {
    await pool.end();
  }
}

main();
