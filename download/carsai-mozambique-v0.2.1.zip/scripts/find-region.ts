import pg from 'pg';
const { Pool } = pg;

const regions = [
  'eu-west-1', 'eu-west-2', 'eu-west-3', 'eu-central-1', 'eu-north-1',
  'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
  'ap-south-1', 'ap-southeast-1', 'ap-northeast-1', 'ap-northeast-2', 'ap-east-1',
  'sa-east-1', 'ca-central-1'
];

const password = 'sb_secret_xrbUv6vEcFL-pKh6NssmJA_pekCAmMC';

async function main() {
  for (const region of regions) {
    const host = `aws-0-${region}.pooler.supabase.com`;
    for (const port of [6543, 5432]) {
      const url = `postgresql://postgres.kngwnzvotefivjmaleup:${password}@${host}:${port}/postgres`;
      const pool = new Pool({
        connectionString: url,
        max: 1,
        connectionTimeoutMillis: 5000,
        idleTimeoutMillis: 5000,
      });
      
      try {
        const result = await pool.query('SELECT current_database()');
        console.log(`CONECTADO: ${region}:${port} - database=${result.rows[0].current_database}`);
        await pool.end();
        return region; // Found the correct region!
      } catch (err: any) {
        const msg = err.message?.substring(0, 80);
        if (msg?.includes('ENOTFOUND') || msg?.includes('NXDOMAIN')) {
          // Skip - DNS doesn't resolve
        } else if (msg?.includes('authentication') || msg?.includes('password') || msg?.includes('53300')) {
          console.log(`AUTH_FAIL: ${region}:${port} - ${msg}`);
        } else if (msg?.includes('timeout') || msg?.includes('refused')) {
          // Skip - port blocked
        } else {
          console.log(`ERROR: ${region}:${port} - ${msg}`);
        }
      }
      try { await pool.end(); } catch {}
    }
  }
  
  console.log('No pooler connection succeeded.');
  return null;
}

main().then(region => {
  if (region) {
    console.log(`\nRegiao correcta: ${region}`);
    console.log(`DATABASE_URL=postgresql://postgres.kngwnzvotefivjmaleup:${password}@aws-0-${region}.pooler.supabase.com:6543/postgres?pgbouncer=true`);
  }
});
