import { Client } from 'pg';

const SQL = `
-- Likes em posts do blog
CREATE TABLE IF NOT EXISTS post_likes (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(post_id, user_id)
);

-- Likes em comentarios do blog
CREATE TABLE IF NOT EXISTS comment_likes (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
  comment_id TEXT NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(comment_id, user_id)
);

-- Likes em posts do forum
CREATE TABLE IF NOT EXISTS forum_post_likes (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id TEXT NOT NULL REFERENCES forum_posts(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(post_id, user_id)
);

-- Indexes para performance
CREATE INDEX IF NOT EXISTS idx_post_likes_post_id ON post_likes(post_id);
CREATE INDEX IF NOT EXISTS idx_post_likes_user_id ON post_likes(user_id);
CREATE INDEX IF NOT EXISTS idx_comment_likes_comment_id ON comment_likes(comment_id);
CREATE INDEX IF NOT EXISTS idx_comment_likes_user_id ON comment_likes(user_id);
CREATE INDEX IF NOT EXISTS idx_forum_post_likes_post_id ON forum_post_likes(post_id);
CREATE INDEX IF NOT EXISTS idx_forum_post_likes_user_id ON forum_post_likes(user_id);

-- Seed: roles e permissoes
INSERT INTO roles (name, description) VALUES
  ('super_admin', 'Administrador supremo com acesso total ao sistema'),
  ('admin', 'Administrador com acesso a painel de gestao'),
  ('partner', 'Parceiro/afiliado com acesso a dashboard de parceiro'),
  ('user', 'Utilizador regular com acesso a funcionalidades basicas')
ON CONFLICT (name) DO NOTHING;

INSERT INTO permissions (name, description) VALUES
  ('admin:full', 'Acesso total ao administrador'),
  ('admin:read', 'Leitura de dados administrativos'),
  ('admin:write', 'Escrita de dados administrativos'),
  ('partner:manage', 'Gerir parceiros e afiliados'),
  ('partner:read', 'Leitura de dados de parceiro'),
  ('user:read', 'Leitura de dados de utilizador'),
  ('user:write', 'Escrita de dados de utilizador'),
  ('forum:post', 'Criar topicos e posts no forum'),
  ('forum:moderate', 'Moderar forum (pin, lock, resolve)'),
  ('blog:write', 'Criar e editar posts no blog'),
  ('blog:comment', 'Comentar em posts do blog')
ON CONFLICT (name) DO NOTHING;

INSERT INTO role_permissions (role_id, permission_id)
  SELECT r.id, p.id FROM roles r, permissions p
  WHERE r.name = 'super_admin'
ON CONFLICT (role_id, permission_id) DO NOTHING;
`;

async function main() {
  // Try multiple connection formats
  const connections = [
    // Direct connection with URL-encoded password
    'postgresql://postgres:Carnanda23%3F@db.kngwnzvotefivjmaleup.supabase.co:5432/postgres',
    // Direct connection with literal password (pg handles escaping)
    { host: 'db.kngwnzvotefivjmaleup.supabase.co', port: 5432, database: 'postgres', user: 'postgres', password: 'Carnanda23?' },
    // IPv6 format sometimes works when DNS resolution issues
    'postgresql://postgres:Carnanda23%3F@db.kngwnzvotefivjmaleup.supabase.co:5432/postgres?sslmode=require',
  ];

  for (let i = 0; i < connections.length; i++) {
    const config = connections[i];
    console.log(`Tentativa ${i + 1}: ${typeof config === 'string' ? config.replace(/:.*@/, ':****@') : `${config.host}:${config.port}`}`);
    
    const client = typeof config === 'string' ? new Client({ connectionString: config }) : new Client(config);
    
    try {
      await client.connect();
      console.log('CONECTADO!');
      
      console.log('Criando tabelas...');
      await client.query(SQL);
      console.log('Tabelas criadas com sucesso!');
      
      // Verify
      const result = await client.query(
        "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name IN ('post_likes', 'comment_likes', 'forum_post_likes') ORDER BY table_name"
      );
      console.log('Tabelas verificadas:', result.rows.map(r => r.table_name));
      
      await client.end();
      return;
    } catch (error: any) {
      console.log(`Falha: ${error.message}`);
      try { await client.end(); } catch {}
    }
  }
  
  console.log('');
  console.log('Todas as tentativas de conexao directa falharam.');
  console.log('A conexao directa ao PostgreSQL esta bloqueada neste ambiente.');
}

main();
