import { Client } from 'pg';

const SQL_CREATE_TABLES = `
CREATE TABLE IF NOT EXISTS post_likes (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(post_id, user_id)
);
CREATE TABLE IF NOT EXISTS comment_likes (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
  comment_id TEXT NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(comment_id, user_id)
);
CREATE TABLE IF NOT EXISTS forum_post_likes (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id TEXT NOT NULL REFERENCES forum_posts(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(post_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_post_likes_post_id ON post_likes(post_id);
CREATE INDEX IF NOT EXISTS idx_post_likes_user_id ON post_likes(user_id);
CREATE INDEX IF NOT EXISTS idx_comment_likes_comment_id ON comment_likes(comment_id);
CREATE INDEX IF NOT EXISTS idx_comment_likes_user_id ON comment_likes(user_id);
CREATE INDEX IF NOT EXISTS idx_forum_post_likes_post_id ON forum_post_likes(post_id);
CREATE INDEX IF NOT EXISTS idx_forum_post_likes_user_id ON forum_post_likes(user_id);
INSERT INTO roles (name, description) VALUES
  ('super_admin', 'Administrador supremo com acesso total ao sistema'),
  ('admin', 'Administrador com acesso a painel de gestao'),
  ('partner', 'Parceiro/afiliado com acesso a dashboard de parceiro'),
  ('user', 'Utilizador regular com acesso a funcionalidades basicas')
ON CONFLICT (name) DO NOTHING;
INSERT INTO permissions (name, description) VALUES
  ('admin:full', 'Acesso total ao administrador'),
  ('admin:read', 'Leitura de dados administrativos'),
  ('admin:write', 'Escrita de dados administrativos'),
  ('partner:manage', 'Gerir parceiros e afiliados'),
  ('partner:read', 'Leitura de dados de parceiro'),
  ('user:read', 'Leitura de dados de utilizador'),
  ('user:write', 'Escrita de dados de utilizador'),
  ('forum:post', 'Criar topicos e posts no forum'),
  ('forum:moderate', 'Moderar forum (pin, lock, resolve)'),
  ('blog:write', 'Criar e editar posts no blog'),
  ('blog:comment', 'Comentar em posts do blog')
ON CONFLICT (name) DO NOTHING;
INSERT INTO role_permissions (role_id, permission_id)
  SELECT r.id, p.id FROM roles r, permissions p
  WHERE r.name = 'super_admin'
ON CONFLICT (role_id, permission_id) DO NOTHING;
`;

// Possible Supabase pooler regions
const regions = ['af-south-1', 'eu-west-1', 'eu-west-2', 'eu-central-1', 'us-east-1', 'us-west-1', 'us-west-2', 'ap-southeast-1', 'ap-northeast-1'];
const passwords = ['Carnanda23%3F', 'sb_secret_xrbUv6vEcFL-pKh6NssmJA_pekCAmMC'];

async function main() {
  for (const region of regions) {
    for (const password of passwords) {
      // Try transaction mode (port 6543) and session mode (port 5432)
      for (const port of [6543, 5432]) {
        const host = `aws-0-${region}.pooler.supabase.com`;
        const url = `postgresql://postgres.kngwnzvotefivjmaleup:${password}@${host}:${port}/postgres`;
        const masked = url.replace(/:.*@/, ':****@');
        console.log(`Tentativa: ${masked}`);
        
        const client = new Client({ connectionString: url });
        try {
          await client.connect({ connectionTimeoutMillis: 5000 });
          console.log(`CONECTADO via ${region}:${port}!`);
          
          await client.query(SQL_CREATE_TABLES);
          console.log('Tabelas criadas com sucesso!');
          
          const result = await client.query(
            "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name IN ('post_likes', 'comment_likes', 'forum_post_likes') ORDER BY table_name"
          );
          console.log('Tabelas verificadas:', result.rows.map(r => r.table_name));
          await client.end();
          return; // Success!
        } catch (error: any) {
          console.log(`Falha: ${error.code || error.message}`);
          try { await client.end(); } catch {}
        }
      }
    }
  }
  
  console.log('');
  console.log('Nenhuma conexao pooler funcionou.');
  console.log('A conexao PostgreSQL esta bloqueada neste ambiente.');
  console.log('Execute o SQL manualmente no Supabase Dashboard SQL Editor.');
}

main();
