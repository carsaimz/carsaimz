/**
 * Script: Create missing tables via Supabase Management API
 * Uses the service role key to authenticate.
 * Since direct PostgreSQL is blocked, we'll create a helper function
 * via the Supabase Dashboard SQL editor instructions.
 */

const SUPABASE_URL = 'https://kngwnzvotefivjmaleup.supabase.co';
const SERVICE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtuZ3duenZvdGVmaXZqbWFsZXVwIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4NTA0Mzk1OCwiZXhwIjoyMTAwNjE5OTU4fQ.7MvMgUgHu8oewoIDqVx1356Y3i-QSz8cuyYfQ-DWkN0';
const ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtuZ3duenZvdGVmaXZqbWFsZXVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODUwNDM5NTgsImV4cCI6MjEwMDYxOTk1OH0.zK1zNkF5cz1XYLN0PEc7fa3ZAQoK7Lr2kwYoHnThRj4';

const MISSING_TABLES_SQL = `
-- Likes em posts do blog
CREATE TABLE IF NOT EXISTS post_likes (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(post_id, user_id)
);

-- Likes em comentarios do blog
CREATE TABLE IF NOT EXISTS comment_likes (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
  comment_id TEXT NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(comment_id, user_id)
);

-- Likes em posts do forum
CREATE TABLE IF NOT EXISTS forum_post_likes (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id TEXT NOT NULL REFERENCES forum_posts(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(post_id, user_id)
);

-- Indexes para performance
CREATE INDEX IF NOT EXISTS idx_post_likes_post_id ON post_likes(post_id);
CREATE INDEX IF NOT EXISTS idx_post_likes_user_id ON post_likes(user_id);
CREATE INDEX IF NOT EXISTS idx_comment_likes_comment_id ON comment_likes(comment_id);
CREATE INDEX IF NOT EXISTS idx_comment_likes_user_id ON comment_likes(user_id);
CREATE INDEX IF NOT EXISTS idx_forum_post_likes_post_id ON forum_post_likes(post_id);
CREATE INDEX IF NOT EXISTS idx_forum_post_likes_user_id ON forum_post_likes(user_id);
`;

async function checkTable(tableName: string): Promise<boolean> {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${tableName}?limit=1`, {
    headers: {
      'apikey': ANON_KEY,
      'Authorization': `Bearer ${ANON_KEY}`,
    },
  });
  const text = await res.text();
  return text.startsWith('[');
}

async function main() {
  console.log('Verificando tabelas missing...');
  
  const tables = ['post_likes', 'comment_likes', 'forum_post_likes'];
  const results: Record<string, boolean> = {};
  
  for (const table of tables) {
    results[table] = await checkTable(table);
    console.log(`${table}: ${results[table] ? 'EXISTE' : 'FALTANDO'}`);
  }
  
  const allExist = Object.values(results).every(v => v);
  
  if (allExist) {
    console.log('');
    console.log('Todas as tabelas ja existem! Base de dados completa.');
    return;
  }
  
  console.log('');
  console.log('===========================================');
  console.log('  CONEXAO DIRECTA AO PostgreSQL NAO DISPONIVEL');
  console.log('===========================================');
  console.log('');
  console.log('Para criar as tabelas missing, execute o SQL');
  console.log('no Supabase Dashboard SQL Editor:');
  console.log('');
  console.log('  1. Acesse: https://supabase.com/dashboard/project/kngwnzvotefivjmaleup/sql');
  console.log('  2. Cole o SQL abaixo');
  console.log('  3. Clique em Run');
  console.log('');
  console.log('--- SQL A EXECUTAR ---');
  console.log(MISSING_TABLES_SQL.trim());
  console.log('--- FIM SQL ---');
  console.log('');
  console.log('Depois de executar, rode este script novamente');
  console.log('para verificar que as tabelas foram criadas.');
}

main();
