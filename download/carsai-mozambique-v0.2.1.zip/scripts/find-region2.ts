import pg from 'pg';
const { Pool } = pg;

const regions = [
  'eu-west-1', 'eu-west-2', 'eu-west-3', 'eu-central-1', 'eu-north-1',
  'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
  'ap-south-1', 'ap-southeast-1', 'ap-northeast-1', 'ap-northeast-2', 'ap-east-1',
  'sa-east-1', 'ca-central-1'
];

// Try both passwords: database password and project secret
const passwords = [
  'Carnanda23?', // Database password
  'sb_secret_xrbUv6vEcFL-pKh6NssmJA_pekCAmMC', // Project secret
];

async function main() {
  for (const region of regions) {
    const host = `aws-0-${region}.pooler.supabase.com`;
    for (const password of passwords) {
      const pwdEncoded = password.includes('?') ? password.replace('?', '%3F') : password;
      for (const port of [6543, 5432]) {
        const url = `postgresql://postgres.kngwnzvotefivjmaleup:${pwdEncoded}@${host}:${port}/postgres`;
        const pool = new Pool({
          connectionString: url,
          max: 1,
          connectionTimeoutMillis: 5000,
          idleTimeoutMillis: 5000,
        });
        
        try {
          const result = await pool.query('SELECT current_database()');
          console.log(`CONECTADO: ${region}:${port} (pwd=${password.includes('?') ? 'db_pass' : 'secret'})`);
          await pool.end();
          return { region, port, password };
        } catch (err: any) {
          const msg = err.message?.substring(0, 100);
          if (msg?.includes('authentication failed')) {
            console.log(`AUTH_FAIL: ${region}:${port} (${password.includes('?') ? 'db_pass' : 'secret'}) - ${msg}`);
          }
        }
        try { await pool.end(); } catch {}
      }
    }
  }
  
  console.log('No pooler connection succeeded.');
  return null;
}

main().then(result => {
  if (result) {
    console.log('\nResultado:');
    console.log(`Regiao: ${result.region}`);
    console.log(`Porta: ${result.port}`);
    console.log(`Password: ${result.password}`);
  }
});
